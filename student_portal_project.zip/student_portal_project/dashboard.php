<?php
require_once 'functions.php';
require_login();

// Handle feedback submission
$feedbackError = '';
$feedbackSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['feedback_action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $feedbackError = 'Invalid request. Please reload the page and try again.';
    } else {
        $message = trim($_POST['message'] ?? '');
        if ($message === '') {
            $feedbackError = 'Feedback message cannot be empty.';
        } else {
            $stmt = $mysqli->prepare('INSERT INTO feedbacks (user_id, message) VALUES (?, ?)');
            $stmt->bind_param('is', $_SESSION['user_id'], $message);
            if ($stmt->execute()) {
                $feedbackSuccess = 'Thanks for your feedback!';
            } else {
                $feedbackError = 'Unable to save feedback. Please try again.';
            }
            $stmt->close();
        }
    }
}

// Fetch recent feedbacks for this user
$stmt = $mysqli->prepare('SELECT message, created_at FROM feedbacks WHERE user_id = ? ORDER BY created_at DESC LIMIT 5');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$feedbacks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch student profile summary (if exists)
$stmt = $mysqli->prepare('SELECT department, year_of_passing, cgpa, placement_status, company, project_title FROM student_profiles WHERE user_id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
$student = $res->fetch_assoc();
$stmt->close();

// Fetch active announcements (not expired or no expiry)
$today = date('Y-m-d');
$stmt = $mysqli->prepare('SELECT title, body, created_at, expires_at FROM announcements
                          WHERE expires_at IS NULL OR expires_at >= ?
                          ORDER BY created_at DESC LIMIT 5');
$stmt->bind_param('s', $today);
$stmt->execute();
$announcements = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Handle last visit cookie
$lastVisitText = '';
if (isset($_COOKIE['last_visit'])) {
    $timestamp = (int)$_COOKIE['last_visit'];
    if ($timestamp > 0) {
        $lastVisitText = date('d M Y h:i A', $timestamp);
    }
}
// Update last_visit cookie to now
setcookie('last_visit', time(), time() + (365 * 24 * 60 * 60), '/');

// CSRF token for forms
$csrf_token = get_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Student Portal</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <div class="top-bar">
        <div>
            <h1>Welcome, <?php echo h($_SESSION['user_name']); ?> 👋</h1>
            <?php if ($lastVisitText): ?>
                <p class="small-text">Last visit: <?php echo h($lastVisitText); ?></p>
            <?php endif; ?>
        </div>
        <div class="top-bar-actions">
            <button type="button" id="themeToggle">Toggle Theme</button>
            <a href="profile.php" class="link-button">Profile</a>
            <a href="resume.php" class="link-button">View Resume</a>
            <?php if (is_admin()): ?>
                <a href="admin_dashboard.php" class="link-button">Admin</a>
                <a href="admin_announcements.php" class="link-button">Announcements</a>
                <a href="admin_placement_report.php" class="link-button">Placement Report</a>
            <?php endif; ?>
            <a href="logout.php" class="link-button danger">Logout</a>
        </div>
    </div>

    <?php display_flash_message(); ?>

    <?php if ($student): ?>
        <div class="stats">
            <div class="stat-box">
                <div class="stat-label">Department</div>
                <div class="stat-value"><?php echo h($student['department'] ?: 'N/A'); ?></div>
            </div>
            <div class="stat-box">
                <div class="stat-label">Year of Passing</div>
                <div class="stat-value"><?php echo h($student['year_of_passing'] ?: 'N/A'); ?></div>
            </div>
            <div class="stat-box">
                <div class="stat-label">CGPA</div>
                <div class="stat-value"><?php echo h($student['cgpa'] ?: 'N/A'); ?></div>
            </div>
            <div class="stat-box">
                <div class="stat-label">Placement Status</div>
                <div class="stat-value"><?php echo h($student['placement_status'] ?: 'Not Placed'); ?></div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (!empty($announcements)): ?>
        <h2>Announcements</h2>
        <ul class="feedback-list">
            <?php foreach ($announcements as $a): ?>
                <li>
                    <div class="feedback-message"><strong><?php echo h($a['title']); ?></strong></div>
                    <div class="feedback-meta">
                        <?php echo h(date('d M Y', strtotime($a['created_at']))); ?>
                        <?php if ($a['expires_at']): ?>
                            • Valid till <?php echo h(date('d M Y', strtotime($a['expires_at']))); ?>
                        <?php endif; ?>
                    </div>
                    <div class="small-text" style="margin-top:4px;">
                        <?php echo nl2br(h($a['body'])); ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <h2>Submit Feedback</h2>

    <?php if ($feedbackError): ?>
        <div class="error"><?php echo h($feedbackError); ?></div>
    <?php endif; ?>

    <?php if ($feedbackSuccess): ?>
        <div class="success"><?php echo h($feedbackSuccess); ?></div>
    <?php endif; ?>

    <form action="dashboard.php" method="post" onsubmit="return validateFeedbackForm();">
        <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
        <input type="hidden" name="feedback_action" value="submit">
        <div class="form-group">
            <label for="feedback_message">Your Feedback</label>
            <textarea id="feedback_message" name="message" rows="3" required></textarea>
        </div>
        <button type="submit">Send Feedback</button>
    </form>

    <?php if (!empty($feedbacks)): ?>
        <h2 style="margin-top:20px;">Recent Feedback</h2>
        <ul class="feedback-list">
            <?php foreach ($feedbacks as $fb): ?>
                <li>
                    <div class="feedback-message"><?php echo h($fb['message']); ?></div>
                    <div class="feedback-meta">
                        <?php echo h(date('d M Y h:i A', strtotime($fb['created_at']))); ?>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
</body>
</html>
