// Client-side validation and small enhancements

function showAlert(message) {
    alert(message);
}

// Registration form validation
function validateRegisterForm() {
    const name = document.getElementById('name')?.value.trim();
    const email = document.getElementById('email')?.value.trim();
    const password = document.getElementById('password')?.value;
    const confirm = document.getElementById('confirm_password')?.value;

    if (!name || !email || !password || !confirm) {
        showAlert("All fields are required.");
        return false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showAlert("Please enter a valid email address.");
        return false;
    }

    if (password.length < 6) {
        showAlert("Password must be at least 6 characters long.");
        return false;
    }

    if (password !== confirm) {
        showAlert("Passwords do not match.");
        return false;
    }

    return true;
}

// Login form validation
function validateLoginForm() {
    const email = document.getElementById('login_email')?.value.trim();
    const password = document.getElementById('login_password')?.value;

    if (!email || !password) {
        showAlert("Email and password are required.");
        return false;
    }
    return true;
}

// Feedback form validation
function validateFeedbackForm() {
    const msg = document.getElementById('feedback_message')?.value.trim();
    if (!msg) {
        showAlert("Feedback message cannot be empty.");
        return false;
    }
    return true;
}

// Theme toggle (sets cookie and toggles class)
function initThemeToggle() {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;

    btn.addEventListener('click', () => {
        const body = document.body;
        const dark = body.classList.toggle('dark');
        document.cookie = "theme=" + (dark ? "dark" : "light") + ";path=/;max-age=31536000";
    });
}

// AJAX email check on registration page
function initEmailCheck() {
    const emailInput = document.getElementById('email');
    const statusEl = document.getElementById('email_status');
    if (!emailInput || !statusEl) return;

    let timeoutId = null;

    emailInput.addEventListener('input', () => {
        statusEl.textContent = '';
        statusEl.style.color = '';
        if (timeoutId) clearTimeout(timeoutId);

        const email = emailInput.value.trim();
        if (!email) return;

        timeoutId = setTimeout(() => {
            fetch('check_email.php?email=' + encodeURIComponent(email))
                .then(r => r.json())
                .then(data => {
                    if (!data.ok) {
                        statusEl.textContent = '';
                        return;
                    }
                    if (data.exists) {
                        statusEl.textContent = data.message;
                        statusEl.style.color = '#b91c1c';
                    } else {
                        statusEl.textContent = data.message;
                        statusEl.style.color = '#15803d';
                    }
                })
                .catch(() => {
                    statusEl.textContent = '';
                });
        }, 500);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    initThemeToggle();
    initEmailCheck();
});

