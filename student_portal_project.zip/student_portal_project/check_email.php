<?php
require_once 'functions.php';

header('Content-Type: application/json');

$email = trim($_GET['email'] ?? '');

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['ok' => false, 'exists' => false, 'message' => 'Invalid email']);
    exit;
}

$stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();
$exists = $stmt->num_rows > 0;
$stmt->close();

echo json_encode([
    'ok' => true,
    'exists' => $exists,
    'message' => $exists ? 'Email already registered' : 'Email available'
]);
?>

