<?php
// config.php - database connection and basic setup

$host = 'localhost';
$db   = 'student_portal';
$user = 'root';      // change if needed
$pass = '';          // change if needed

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_errno) {
    die('Failed to connect to MySQL: ' . $mysqli->connect_error);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set default timezone
date_default_timezone_set('Asia/Kolkata');

// Read theme cookie (light/dark)
$theme = (isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark') ? 'dark' : 'light';
?>

