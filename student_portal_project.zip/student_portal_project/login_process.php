<?php
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    redirect_with_message('login.php', 'error', 'Invalid request. Please try again.');
}

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if ($email === '' || $password === '') {
    redirect_with_message('login.php', 'error', 'Email and password are required.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirect_with_message('login.php', 'error', 'Invalid email address.');
}

// Fetch user
$stmt = $mysqli->prepare('SELECT id, name, password_hash, role FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user || !password_verify($password, $user['password_hash'])) {
    redirect_with_message('login.php', 'error', 'Incorrect email or password.');
}

// Set session variables
$_SESSION['user_id'] = $user['id'];
$_SESSION['user_name'] = $user['name'];
$_SESSION['role'] = $user['role'];

// Handle "Remember my email" cookie
if (!empty($_POST['remember'])) {
    setcookie('user_email', $email, time() + (7 * 24 * 60 * 60), '/'); // 7 days
} else {
    setcookie('user_email', '', time() - 3600, '/');
}

// Set/update last visit cookie (actual display happens on dashboard)
if (!isset($_COOKIE['last_visit'])) {
    setcookie('last_visit', time(), time() + (365 * 24 * 60 * 60), '/');
}

redirect_with_message('dashboard.php', 'success', 'Welcome back, ' . $user['name'] . '!');
?>

