<?php
require_once 'functions.php';
require_admin();

$adminError = '';
$adminSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $adminError = 'Invalid request. Please reload and try again.';
    } else {
        $action = $_POST['action'] ?? '';

        // Add / update announcement (here we only add for simplicity)
        if ($action === 'add') {
            $title = trim($_POST['title'] ?? '');
            $body = trim($_POST['body'] ?? '');
            $expires_at = trim($_POST['expires_at'] ?? '');

            if ($title === '' || $body === '') {
                $adminError = 'Title and message are required.';
            } else {
                $stmt = $mysqli->prepare('INSERT INTO announcements (title, body, expires_at, created_by) VALUES (?, ?, ?, ?)');
                $expires = $expires_at !== '' ? $expires_at : null;
                $stmt->bind_param('sssi', $title, $body, $expires, $_SESSION['user_id']);
                if ($stmt->execute()) {
                    $adminSuccess = 'Announcement added.';
                } else {
                    $adminError = 'Failed to add announcement.';
                }
                $stmt->close();
            }

        // Delete announcement
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $stmt = $mysqli->prepare('DELETE FROM announcements WHERE id = ?');
                $stmt->bind_param('i', $id);
                if ($stmt->execute()) {
                    $adminSuccess = 'Announcement deleted.';
                } else {
                    $adminError = 'Failed to delete announcement.';
                }
                $stmt->close();
            }
        }
    }
}

// Fetch all announcements (latest first)
$res = $mysqli->query('SELECT a.id, a.title, a.body, a.created_at, a.expires_at, u.name AS creator_name
                       FROM announcements a
                       LEFT JOIN users u ON a.created_by = u.id
                       ORDER BY a.created_at DESC');
$announcements = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];

$csrf_token = get_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Announcements - Admin</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <div class="top-bar">
        <h1>Announcements (Admin)</h1>
        <div class="top-bar-actions">
            <button type="button" id="themeToggle">Toggle Theme</button>
            <a href="admin_dashboard.php" class="link-button">Admin Home</a>
            <a href="admin_placement_report.php" class="link-button">Placement Report</a>
            <a href="dashboard.php" class="link-button">Dashboard</a>
            <a href="logout.php" class="link-button danger">Logout</a>
        </div>
    </div>

    <?php if ($adminError): ?>
        <div class="error"><?php echo h($adminError); ?></div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="success"><?php echo h($adminSuccess); ?></div>
    <?php endif; ?>

    <h2>Create New Announcement</h2>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
        <input type="hidden" name="action" value="add">

        <div class="form-group">
            <label for="title">Title</label>
            <input id="title" name="title" type="text" required>
        </div>

        <div class="form-group">
            <label for="body">Message</label>
            <textarea id="body" name="body" rows="3" required></textarea>
        </div>

        <div class="form-group">
            <label for="expires_at">Expiry Date (optional)</label>
            <input id="expires_at" name="expires_at" type="date">
        </div>

        <button type="submit">Publish Announcement</button>
    </form>

    <h2 style="margin-top: 20px;">Existing Announcements</h2>
    <div class="table-wrapper">
        <table>
            <thead>
            <tr>
                <th>Title</th>
                <th>Message</th>
                <th>Created</th>
                <th>Expires</th>
                <th>Created By</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!empty($announcements)): ?>
                <?php foreach ($announcements as $a): ?>
                    <tr>
                        <td><?php echo h($a['title']); ?></td>
                        <td class="col-wide"><?php echo nl2br(h($a['body'])); ?></td>
                        <td><?php echo h(date('d M Y', strtotime($a['created_at']))); ?></td>
                        <td>
                            <?php echo $a['expires_at'] ? h(date('d M Y', strtotime($a['expires_at']))) : '—'; ?>
                        </td>
                        <td><?php echo h($a['creator_name'] ?? 'Unknown'); ?></td>
                        <td>
                            <form method="post" onsubmit="return confirm('Delete this announcement?');">
                                <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo (int)$a['id']; ?>">
                                <button type="submit" class="small-btn danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">No announcements yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="assets/script.js" defer></script>
</body>
</html>
