<?php
require_once 'functions.php';

// If already logged in, redirect to dashboard
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$remembered_email = $_COOKIE['user_email'] ?? '';
$csrf_token = get_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Student Portal</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <h1>Student Portal</h1>
    <h2>Login</h2>

    <?php display_flash_message(); ?>

    <form action="login_process.php" method="post" onsubmit="return validateLoginForm();">
        <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">

        <div class="form-group">
            <label for="login_email">Email</label>
            <input
                type="email"
                id="login_email"
                name="email"
                value="<?php echo h($remembered_email); ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="login_password">Password</label>
            <input
                type="password"
                id="login_password"
                name="password"
                required
            >
        </div>

        <div class="form-group checkbox-row">
            <input
                type="checkbox"
                id="remember"
                name="remember"
                <?php echo $remembered_email ? 'checked' : ''; ?>
            >
            <label for="remember">Remember my email on this device</label>
        </div>

        <button type="submit">Login</button>
    </form>

    <p class="small-text">
        Don’t have an account?
        <a href="register.php">Register here</a>
    </p>
</div>
</body>
</html>

