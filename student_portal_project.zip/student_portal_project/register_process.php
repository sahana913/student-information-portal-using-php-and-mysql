<?php
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
    redirect_with_message('register.php', 'error', 'Invalid request. Please try again.');
}

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

// Basic server-side validation
if ($name === '' || $email === '' || $password === '' || $confirm === '') {
    redirect_with_message('register.php', 'error', 'All fields are required.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirect_with_message('register.php', 'error', 'Invalid email address.');
}

if (strlen($password) < 6) {
    redirect_with_message('register.php', 'error', 'Password must be at least 6 characters.');
}

if ($password !== $confirm) {
    redirect_with_message('register.php', 'error', 'Passwords do not match.');
}

// Check if email already exists
$stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    redirect_with_message('register.php', 'error', 'Email is already registered.');
}
$stmt->close();

// Determine role (first user = admin)
$result = $mysqli->query('SELECT COUNT(*) AS cnt FROM users');
$row = $result ? $result->fetch_assoc() : null;
$role = ($row && (int)$row['cnt'] === 0) ? 'admin' : 'user';

$password_hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $mysqli->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
$stmt->bind_param('ssss', $name, $email, $password_hash, $role);

if ($stmt->execute()) {
    $stmt->close();
    redirect_with_message('login.php', 'success', 'Registration successful. Please login.');
} else {
    $stmt->close();
    redirect_with_message('register.php', 'error', 'Something went wrong. Please try again.');
}
?>

