<?php
require_once 'functions.php';
require_login();

$user_id = $_SESSION['user_id'];

// Fetch user info
$stmt = $mysqli->prepare('SELECT name, email, created_at, profile_picture, password_hash FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    die('User not found.');
}

$profileError = '';
$profileSuccess = '';

// Fetch student profile (placement & project details)
$stmt = $mysqli->prepare('SELECT phone, department, year_of_passing, cgpa, skills, placement_status, company, project_title, project_description FROM student_profiles WHERE user_id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();
$student = $res->fetch_assoc();
$stmt->close();

if (!$student) {
    // Default empty values
    $student = [
        'phone' => '',
        'department' => '',
        'year_of_passing' => '',
        'cgpa' => '',
        'skills' => '',
        'placement_status' => 'Not Placed',
        'company' => '',
        'project_title' => '',
        'project_description' => ''
    ];
}

// Handle profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $profileError = 'Invalid request. Please reload the page and try again.';
    } else {
        $action = $_POST['action'] ?? '';

        // Update basic profile (name + email)
        if ($action === 'update_profile') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');

            if ($name === '' || $email === '') {
                $profileError = 'Name and email cannot be empty.';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $profileError = 'Invalid email address.';
            } else {
                // Check if email already used by someone else
                $stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
                $stmt->bind_param('si', $email, $user_id);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows > 0) {
                    $profileError = 'Email is already used by another account.';
                } else {
                    $stmt->close();
                    $stmt = $mysqli->prepare('UPDATE users SET name = ?, email = ? WHERE id = ?');
                    $stmt->bind_param('ssi', $name, $email, $user_id);
                    if ($stmt->execute()) {
                        $profileSuccess = 'Profile updated successfully.';
                        $_SESSION['user_name'] = $name;
                        $user['name'] = $name;
                        $user['email'] = $email;
                    } else {
                        $profileError = 'Failed to update profile.';
                    }
                }
                $stmt->close();
            }

        // Change password
        } elseif ($action === 'change_password') {
            $current = $_POST['current_password'] ?? '';
            $new = $_POST['new_password'] ?? '';
            $confirm = $_POST['confirm_new_password'] ?? '';

            if ($current === '' || $new === '' || $confirm === '') {
                $profileError = 'All password fields are required.';
            } elseif (!password_verify($current, $user['password_hash'])) {
                $profileError = 'Current password is incorrect.';
            } elseif (strlen($new) < 6) {
                $profileError = 'New password must be at least 6 characters.';
            } elseif ($new !== $confirm) {
                $profileError = 'New passwords do not match.';
            } else {
                $new_hash = password_hash($new, PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
                $stmt->bind_param('si', $new_hash, $user_id);
                if ($stmt->execute()) {
                    $profileSuccess = 'Password changed successfully.';
                    $user['password_hash'] = $new_hash;
                } else {
                    $profileError = 'Failed to change password.';
                }
                $stmt->close();
            }

        // Upload profile picture
        } elseif ($action === 'upload_picture') {
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
                $fileTmp = $_FILES['profile_picture']['tmp_name'];
                $fileName = $_FILES['profile_picture']['name'];
                $fileSize = $_FILES['profile_picture']['size'];

                $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png'];

                if (!in_array($ext, $allowed)) {
                    $profileError = 'Only JPG and PNG images are allowed.';
                } elseif ($fileSize > 2 * 1024 * 1024) {
                    $profileError = 'File size must be less than 2MB.';
                } else {
                    $newName = 'user_' . $user_id . '_' . time() . '.' . $ext;

                    // Ensure uploads directory exists
                    $uploadDir = __DIR__ . '/uploads';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0777, true);
                    }

                    $destination = $uploadDir . '/' . $newName;

                    if (move_uploaded_file($fileTmp, $destination)) {
                        $stmt = $mysqli->prepare('UPDATE users SET profile_picture = ? WHERE id = ?');
                        $stmt->bind_param('si', $newName, $user_id);
                        if ($stmt->execute()) {
                            $profileSuccess = 'Profile picture updated.';
                            $user['profile_picture'] = $newName;
                        } else {
                            $profileError = 'Failed to save profile picture.';
                        }
                        $stmt->close();
                    } else {
                        $profileError = 'Failed to upload file.';
                    }
                }
            } else {
                $profileError = 'Please select a file to upload.';
            }

        // Academic & placement details
        } elseif ($action === 'update_academic') {
            $phone = trim($_POST['phone'] ?? '');
            $department = trim($_POST['department'] ?? '');
            $year = (int)($_POST['year_of_passing'] ?? 0);
            $cgpa = trim($_POST['cgpa'] ?? '');
            $skills = trim($_POST['skills'] ?? '');
            $placement_status = $_POST['placement_status'] ?? 'Not Placed';
            $company = trim($_POST['company'] ?? '');
            $project_title = trim($_POST['project_title'] ?? '');
            $project_description = trim($_POST['project_description'] ?? '');

            // Basic validation
            if ($year && ($year < 2000 || $year > 2100)) {
                $profileError = 'Enter a valid passing year.';
            } else {
                // Check if profile row already exists
                $stmt = $mysqli->prepare('SELECT id FROM student_profiles WHERE user_id = ?');
                $stmt->bind_param('i', $user_id);
                $stmt->execute();
                $stmt->store_result();
                $exists = $stmt->num_rows > 0;
                $stmt->close();

                if ($exists) {
                    $stmt = $mysqli->prepare('UPDATE student_profiles
                        SET phone = ?, department = ?, year_of_passing = ?, cgpa = ?, skills = ?,
                            placement_status = ?, company = ?, project_title = ?, project_description = ?
                        WHERE user_id = ?');
                    $stmt->bind_param(
                        'ssissssssi',
                        $phone,
                        $department,
                        $year,
                        $cgpa,
                        $skills,
                        $placement_status,
                        $company,
                        $project_title,
                        $project_description,
                        $user_id
                    );
                } else {
                    $stmt = $mysqli->prepare('INSERT INTO student_profiles
                        (phone, department, year_of_passing, cgpa, skills, placement_status, company, project_title, project_description, user_id)
                        VALUES (?,?,?,?,?,?,?,?,?,?)');
                    $stmt->bind_param(
                        'ssissssssi',
                        $phone,
                        $department,
                        $year,
                        $cgpa,
                        $skills,
                        $placement_status,
                        $company,
                        $project_title,
                        $project_description,
                        $user_id
                    );
                }

                if ($stmt->execute()) {
                    $profileSuccess = 'Academic & placement details updated.';
                    $student = [
                        'phone' => $phone,
                        'department' => $department,
                        'year_of_passing' => $year,
                        'cgpa' => $cgpa,
                        'skills' => $skills,
                        'placement_status' => $placement_status,
                        'company' => $company,
                        'project_title' => $project_title,
                        'project_description' => $project_description
                    ];
                } else {
                    $profileError = 'Failed to save academic details.';
                }
                $stmt->close();
            }
        }
    }
}

$csrf_token = get_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile - Student Portal</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <div class="top-bar">
        <h1>Your Profile</h1>
        <div class="top-bar-actions">
            <button type="button" id="themeToggle">Toggle Theme</button>
            <a href="dashboard.php" class="link-button">Dashboard</a>
            <?php if (is_admin()): ?>
                <a href="admin_dashboard.php" class="link-button">Admin</a>
            <?php endif; ?>
            <a href="logout.php" class="link-button danger">Logout</a>
        </div>
    </div>

    <?php if ($profileError): ?>
        <div class="error"><?php echo h($profileError); ?></div>
    <?php endif; ?>

    <?php if ($profileSuccess): ?>
        <div class="success"><?php echo h($profileSuccess); ?></div>
    <?php endif; ?>

    <div class="profile-layout">
        <div class="profile-left">
            <div class="avatar-box">
                <?php if (!empty($user['profile_picture'])): ?>
                    <img src="uploads/<?php echo h($user['profile_picture']); ?>" alt="Profile Picture" class="avatar">
                <?php else: ?>
                    <div class="avatar placeholder">
                        <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
            </div>

            <form action="profile.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                <input type="hidden" name="action" value="upload_picture">
                <div class="form-group">
                    <label for="profile_picture">Change Profile Picture</label>
                    <input type="file" name="profile_picture" id="profile_picture" accept="image/*">
                </div>
                <button type="submit">Upload Picture</button>
            </form>
        </div>

        <div class="profile-right">
            <h2>Account Details</h2>
            <form action="profile.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                <input type="hidden" name="action" value="update_profile">

                <div class="form-group">
                    <label for="p_name">Full Name</label>
                    <input type="text" id="p_name" name="name" value="<?php echo h($user['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="p_email">Email</label>
                    <input type="email" id="p_email" name="email" value="<?php echo h($user['email']); ?>" required>
                </div>

                <div class="form-group">
                    <label>Member Since</label>
                    <input type="text" value="<?php echo h(date('d M Y', strtotime($user['created_at']))); ?>" disabled>
                </div>

                <button type="submit">Save Changes</button>
            </form>

            <h2 style="margin-top: 20px;">Change Password</h2>
            <form action="profile.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                <input type="hidden" name="action" value="change_password">

                <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" id="current_password" name="current_password" required>
                </div>

                <div class="form-group">
                    <label for="new_password">New Password (min 6 chars)</label>
                    <input type="password" id="new_password" name="new_password" minlength="6" required>
                </div>

                <div class="form-group">
                    <label for="confirm_new_password">Confirm New Password</label>
                    <input type="password" id="confirm_new_password" name="confirm_new_password" minlength="6" required>
                </div>

                <button type="submit">Change Password</button>
            </form>

            <h2 style="margin-top: 20px;">Academic & Placement Details</h2>
            <form action="profile.php" method="post">
                <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                <input type="hidden" name="action" value="update_academic">

                <div class="form-group">
                    <label for="phone">Mobile Number</label>
                    <input type="text" id="phone" name="phone" value="<?php echo h($student['phone']); ?>">
                </div>

                <div class="form-group">
                    <label for="department">Department / Branch</label>
                    <input type="text" id="department" name="department" value="<?php echo h($student['department']); ?>">
                </div>

                <div class="form-group">
                    <label for="year_of_passing">Year of Passing</label>
                    <input type="number" id="year_of_passing" name="year_of_passing" value="<?php echo h($student['year_of_passing']); ?>">
                </div>

                <div class="form-group">
                    <label for="cgpa">CGPA</label>
                    <input type="text" id="cgpa" name="cgpa" value="<?php echo h($student['cgpa']); ?>">
                </div>

                <div class="form-group">
                    <label for="skills">Key Skills (comma separated)</label>
                    <textarea id="skills" name="skills" rows="2"><?php echo h($student['skills']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="placement_status">Placement Status</label>
                    <select id="placement_status" name="placement_status">
                        <?php
                        $statuses = ['Not Placed', 'Intern', 'Placed'];
                        foreach ($statuses as $st) {
                            $sel = ($student['placement_status'] === $st) ? 'selected' : '';
                            echo '<option value="' . h($st) . '" ' . $sel . '>' . h($st) . '</option>';
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="company">Company (if Placed / Intern)</label>
                    <input type="text" id="company" name="company" value="<?php echo h($student['company']); ?>">
                </div>

                <div class="form-group">
                    <label for="project_title">Final Year Project Title</label>
                    <input type="text" id="project_title" name="project_title" value="<?php echo h($student['project_title']); ?>">
                </div>

                <div class="form-group">
                    <label for="project_description">Project Description</label>
                    <textarea id="project_description" name="project_description" rows="3"><?php echo h($student['project_description']); ?></textarea>
                </div>

                <button type="submit">Save Academic & Placement Details</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
