<?php
require_once 'functions.php';
require_admin();

// Handle delete feedback
$adminError = '';
$adminSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_feedback_id'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $adminError = 'Invalid request. Please reload and try again.';
    } else {
        $fid = (int)($_POST['delete_feedback_id'] ?? 0);
        if ($fid > 0) {
            $stmt = $mysqli->prepare('DELETE FROM feedbacks WHERE id = ?');
            $stmt->bind_param('i', $fid);
            if ($stmt->execute()) {
                $adminSuccess = 'Feedback deleted.';
            } else {
                $adminError = 'Failed to delete feedback.';
            }
            $stmt->close();
        }
    }
}

// Gather stats
$res = $mysqli->query('SELECT COUNT(*) AS cnt FROM users');
$usersCount = ($res && $row = $res->fetch_assoc()) ? (int)$row['cnt'] : 0;

$res = $mysqli->query('SELECT COUNT(*) AS cnt FROM feedbacks');
$feedbackCount = ($res && $row = $res->fetch_assoc()) ? (int)$row['cnt'] : 0;

// Fetch users list
$usersResult = $mysqli->query('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC');

// Fetch feedback with user info
$feedbackResult = $mysqli->query('
    SELECT f.id, f.message, f.created_at, u.name, u.email
    FROM feedbacks f
    JOIN users u ON f.user_id = u.id
    ORDER BY f.created_at DESC
    LIMIT 50
');

$csrf_token = get_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Student Portal</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <div class="top-bar">
        <h1>Admin Dashboard</h1>
        <div class="top-bar-actions">
            <button type="button" id="themeToggle">Toggle Theme</button>
            <a href="dashboard.php" class="link-button">Dashboard</a>
            <a href="profile.php" class="link-button">Profile</a>
            <a href="logout.php" class="link-button danger">Logout</a>
        </div>
    </div>

    <?php if ($adminError): ?>
        <div class="error"><?php echo h($adminError); ?></div>
    <?php endif; ?>

    <?php if ($adminSuccess): ?>
        <div class="success"><?php echo h($adminSuccess); ?></div>
    <?php endif; ?>

    <div class="stats">
        <div class="stat-box">
            <div class="stat-label">Total Users</div>
            <div class="stat-value"><?php echo $usersCount; ?></div>
        </div>
        <div class="stat-box">
            <div class="stat-label">Total Feedback</div>
            <div class="stat-value"><?php echo $feedbackCount; ?></div>
        </div>
    </div>

    <h2>Users</h2>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Joined</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($usersResult && $usersResult->num_rows > 0): ?>
                    <?php while ($u = $usersResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo (int)$u['id']; ?></td>
                            <td><?php echo h($u['name']); ?></td>
                            <td><?php echo h($u['email']); ?></td>
                            <td><?php echo h($u['role']); ?></td>
                            <td><?php echo h(date('d M Y', strtotime($u['created_at']))); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5">No users found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <h2 style="margin-top: 20px;">Recent Feedback</h2>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($feedbackResult && $feedbackResult->num_rows > 0): ?>
                    <?php while ($f = $feedbackResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo (int)$f['id']; ?></td>
                            <td><?php echo h($f['name']); ?></td>
                            <td><?php echo h($f['email']); ?></td>
                            <td class="col-wide"><?php echo h($f['message']); ?></td>
                            <td><?php echo h(date('d M Y h:i A', strtotime($f['created_at']))); ?></td>
                            <td>
                                <form action="admin_dashboard.php" method="post" onsubmit="return confirm('Delete this feedback?');">
                                    <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                                    <input type="hidden" name="delete_feedback_id" value="<?php echo (int)$f['id']; ?>">
                                    <button type="submit" class="small-btn danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6">No feedback found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>

