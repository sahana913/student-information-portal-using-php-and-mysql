<?php
require_once 'functions.php';

session_unset();
session_destroy();

// Also clear cookies if you like
setcookie('PHPSESSID', '', time() - 3600, '/');

redirect_with_message('login.php', 'success', 'You have been logged out.');
?>

