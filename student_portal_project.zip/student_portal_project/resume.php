<?php
require_once 'functions.php';
require_login();

$user_id = $_SESSION['user_id'];

// Fetch user
$stmt = $mysqli->prepare('SELECT name, email, created_at FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if (!$user) {
    die('User not found.');
}

// Fetch student profile (academic + placement)
$stmt = $mysqli->prepare('SELECT phone, department, year_of_passing, cgpa, skills, placement_status, company, project_title, project_description
                          FROM student_profiles WHERE user_id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();
$profile = $res->fetch_assoc();
$stmt->close();

if (!$profile) {
    // Default empty values
    $profile = [
        'phone' => '',
        'department' => '',
        'year_of_passing' => '',
        'cgpa' => '',
        'skills' => '',
        'placement_status' => 'Not Placed',
        'company' => '',
        'project_title' => '',
        'project_description' => ''
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume - <?php echo h($user['name']); ?></title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        body.resume-body {
            background: #f3f4f6 !important;
            display: block;
            padding: 20px;
        }
        .resume-page {
            background: #ffffff;
            max-width: 800px;
            margin: 0 auto;
            padding: 24px 28px;
            border-radius: 8px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.12);
        }
        .resume-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid #e5e7eb;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .resume-name {
            font-size: 22px;
            font-weight: 700;
        }
        .resume-contact {
            text-align: right;
            font-size: 13px;
        }
        .resume-section-title {
            font-size: 15px;
            font-weight: 700;
            margin-top: 14px;
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .resume-section-body {
            font-size: 13px;
            margin-bottom: 4px;
        }
        .resume-pill {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 999px;
            background: #e5e7eb;
            font-size: 12px;
            margin-right: 4px;
            margin-bottom: 4px;
        }
        @media print {
            body.resume-body {
                background: #ffffff !important;
                padding: 0;
            }
            .resume-page {
                box-shadow: none;
                border-radius: 0;
                margin: 0;
                width: 100%;
            }
            .resume-actions {
                display: none;
            }
        }
    </style>
</head>
<body class="resume-body">
<div class="resume-actions" style="max-width: 800px; margin: 0 auto 8px; display:flex; justify-content: space-between; align-items:center;">
    <div>
        <a href="dashboard.php" class="link-button">Back to Dashboard</a>
    </div>
    <div>
        <button onclick="window.print()">Print / Save as PDF</button>
    </div>
</div>

<div class="resume-page">
    <div class="resume-header">
        <div>
            <div class="resume-name"><?php echo h($user['name']); ?></div>
            <div class="resume-section-body">
                <?php echo h($profile['department'] ?: 'Student'); ?>
                <?php if ($profile['year_of_passing']): ?>
                    • Batch of <?php echo h($profile['year_of_passing']); ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="resume-contact">
            <div><?php echo h($user['email']); ?></div>
            <?php if ($profile['phone']): ?>
                <div><?php echo h($profile['phone']); ?></div>
            <?php endif; ?>
            <?php if ($profile['placement_status']): ?>
                <div>Status: <?php echo h($profile['placement_status']); ?></div>
            <?php endif; ?>
            <?php if ($profile['company']): ?>
                <div>Company: <?php echo h($profile['company']); ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="resume-section">
        <div class="resume-section-title">Academic Details</div>
        <div class="resume-section-body">
            <strong>Department:</strong> <?php echo h($profile['department'] ?: 'N/A'); ?><br>
            <strong>Year of Passing:</strong> <?php echo h($profile['year_of_passing'] ?: 'N/A'); ?><br>
            <strong>CGPA:</strong> <?php echo h($profile['cgpa'] ?: 'N/A'); ?>
        </div>
    </div>

    <div class="resume-section">
        <div class="resume-section-title">Skills</div>
        <div class="resume-section-body">
            <?php
            if (!empty($profile['skills'])) {
                $skills = explode(',', $profile['skills']);
                foreach ($skills as $sk) {
                    $sk = trim($sk);
                    if ($sk === '') continue;
                    echo '<span class="resume-pill">' . h($sk) . '</span>';
                }
            } else {
                echo 'N/A';
            }
            ?>
        </div>
    </div>

    <div class="resume-section">
        <div class="resume-section-title">Final Year Project</div>
        <div class="resume-section-body">
            <strong>Title:</strong> <?php echo h($profile['project_title'] ?: 'N/A'); ?><br><br>
            <?php if ($profile['project_description']): ?>
                <?php echo nl2br(h($profile['project_description'])); ?>
            <?php else: ?>
                Description not provided.
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
