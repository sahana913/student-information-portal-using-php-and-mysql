<?php
require_once 'functions.php';
$csrf_token = get_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Student Portal</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="assets/script.js" defer></script>
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <h1>Student Portal</h1>
    <h2>Create Account</h2>

    <?php display_flash_message(); ?>

    <form action="register_process.php" method="post" onsubmit="return validateRegisterForm();">
        <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">

        <div class="form-group">
            <label for="name">Full Name</label>
            <input
                type="text"
                id="name"
                name="name"
                required
            >
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input
                type="email"
                id="email"
                name="email"
                required
            >
            <small id="email_status" class="hint"></small>
        </div>

        <div class="form-group">
            <label for="password">Password (min 6 chars)</label>
            <input
                type="password"
                id="password"
                name="password"
                minlength="6"
                required
            >
        </div>

        <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input
                type="password"
                id="confirm_password"
                name="confirm_password"
                minlength="6"
                required
            >
        </div>

        <button type="submit">Register</button>
    </form>

    <p class="small-text">
        Already have an account?
        <a href="login.php">Login here</a>
    </p>
</div>
</body>
</html>

