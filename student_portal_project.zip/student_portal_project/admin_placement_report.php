<?php
require_once 'functions.php';
require_admin();

// Filters
$department = trim($_GET['department'] ?? '');
$year = trim($_GET['year'] ?? '');
$status = trim($_GET['status'] ?? '');
$search = trim($_GET['search'] ?? '');

$where = [];
$params = [];
$types = '';

if ($department !== '') {
    $where[] = 'sp.department LIKE ?';
    $params[] = '%' . $department . '%';
    $types .= 's';
}
if ($year !== '') {
    $where[] = 'sp.year_of_passing = ?';
    $params[] = (int)$year;
    $types .= 'i';
}
if ($status !== '') {
    $where[] = 'sp.placement_status = ?';
    $params[] = $status;
    $types .= 's';
}
if ($search !== '') {
    $where[] = '(u.name LIKE ? OR u.email LIKE ? OR sp.company LIKE ? OR sp.project_title LIKE ?)';
    $like = '%' . $search . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $types .= 'ssss';
}

$sql = '
    SELECT 
        u.name,
        u.email,
        sp.department,
        sp.year_of_passing,
        sp.cgpa,
        sp.skills,
        sp.placement_status,
        sp.company,
        sp.project_title
    FROM users u
    JOIN student_profiles sp ON u.id = sp.user_id
';

if (!empty($where)) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}

$sql .= ' ORDER BY sp.year_of_passing DESC, sp.department ASC, u.name ASC';

$stmt = $mysqli->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$rows = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Placement Report - Student Portal</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="<?php echo $theme === 'dark' ? 'dark' : ''; ?>">
<div class="container">
    <div class="top-bar">
        <h1>Placement Report</h1>
        <div class="top-bar-actions">
            <button type="button" id="themeToggle">Toggle Theme</button>
            <a href="admin_dashboard.php" class="link-button">Admin Home</a>
            <a href="dashboard.php" class="link-button">Dashboard</a>
            <a href="logout.php" class="link-button danger">Logout</a>
        </div>
    </div>

    <form method="get" class="filters-form" style="margin-bottom: 12px;">
        <div class="form-group">
            <label for="dept">Department</label>
            <input type="text" id="dept" name="department" value="<?php echo h($department); ?>">
        </div>

        <div class="form-group">
            <label for="year">Year of Passing</label>
            <input type="number" id="year" name="year" value="<?php echo h($year); ?>">
        </div>

        <div class="form-group">
            <label for="status">Placement Status</label>
            <select id="status" name="status">
                <option value="">-- Any --</option>
                <?php
                $statuses = ['Not Placed', 'Intern', 'Placed'];
                foreach ($statuses as $st) {
                    $sel = ($status === $st) ? 'selected' : '';
                    echo '<option value="' . h($st) . '" ' . $sel . '>' . h($st) . '</option>';
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="search">Search (name / email / company / project)</label>
            <input type="text" id="search" name="search" value="<?php echo h($search); ?>">
        </div>

        <button type="submit">Apply Filters</button>
    </form>

    <div class="table-wrapper">
        <table>
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Dept</th>
                <th>YOP</th>
                <th>CGPA</th>
                <th>Status</th>
                <th>Company</th>
                <th>Project Title</th>
                <th>Skills</th>
            </tr>
            </thead>
            <tbody>
            <?php if (!empty($rows)): ?>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><?php echo h($r['name']); ?></td>
                        <td><?php echo h($r['email']); ?></td>
                        <td><?php echo h($r['department']); ?></td>
                        <td><?php echo h($r['year_of_passing']); ?></td>
                        <td><?php echo h($r['cgpa']); ?></td>
                        <td>
                            <?php
                            $st = $r['placement_status'];
                            $class = 'badge';
                            if ($st === 'Placed') $class .= ' badge-success';
                            elseif ($st === 'Intern') $class .= ' badge-info';
                            else $class .= ' badge-muted';
                            ?>
                            <span class="<?php echo $class; ?>"><?php echo h($st); ?></span>
                        </td>
                        <td><?php echo h($r['company']); ?></td>
                        <td><?php echo h($r['project_title']); ?></td>
                        <td><?php echo h($r['skills']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="9">No records found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="assets/script.js" defer></script>
</body>
</html>
