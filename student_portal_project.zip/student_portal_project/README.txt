Student Portal PHP Project
==========================

This project demonstrates:
- Client-side validation (JavaScript + HTML5)
- Server-side validation (PHP)
- Sessions (login/logout, role-based access)
- Cookies ("remember my email", theme preference, last visit time)
- Profile management (update info, change password, upload profile picture)
- Admin panel (view users & feedback, delete feedback)
- Basic security: CSRF token + XSS-safe output
- Decent CSS with light/dark theme

Setup steps
-----------

1. Copy the "student_portal_project" folder into your web server root:
   - XAMPP (Windows): C:\xampp\htdocs\student_portal_project
   - WAMP: C:\wamp64\www\student_portal_project

2. Create the database:
   - Open phpMyAdmin (http://localhost/phpmyadmin).
   - Go to the SQL tab.
   - Open the file db.sql from this project and execute its contents
     OR simply import the db.sql file.

3. Configure database login:
   - Open config.php and adjust:
       $host, $db, $user, $pass
     to match your MySQL/XAMPP settings.
   - Default values are usually fine: root with empty password.

4. Make sure the "uploads" folder is writable:
   - On Windows this is usually fine.
   - On Linux/Mac, you may need: chmod 777 uploads

5. Run the project:
   - Open browser and go to:
       http://localhost/student_portal_project/
   - Register the first user (this user automatically becomes ADMIN).
   - Then you can log in, submit feedback, update profile, and
     access the Admin Dashboard (link appears for admin users).

Main files
----------

- index.php          -> redirects to login or dashboard depending on session
- config.php         -> DB connection + timezone + theme cookie
- functions.php      -> helper functions (sessions, flash messages, CSRF)
- register.php       -> registration form (with client-side + server-side validation)
- register_process.php -> handles registration logic
- login.php          -> login form (uses cookie to remember email)
- login_process.php  -> handles login logic and sets session + cookies
- dashboard.php      -> protected page with feedback form and last visit display
- profile.php        -> profile page (update info, change password, upload photo)
- admin_dashboard.php -> admin-only page with user & feedback management
- check_email.php    -> AJAX endpoint to check if email is already registered
- assets/style.css   -> main styles
- assets/script.js   -> JS for validation, theme toggle, AJAX email check
- uploads/           -> folder to store profile pictures

You can extend this project by:
- Adding pagination & search for feedback
- Adding user deletion / banning in the admin panel
- Adding a simple password reset flow
- Creating more modules (e.g. courses, events, etc.) using the same patterns.


